# แบบฝึกหัด: สัปดาห์ที่ 7 - Responsive Web Design & Media Queries

## 🎯 โจทย์: สร้างเว็บไซต์ร้านอาหาร (Restaurant Website) แบบ Responsive

### 📋 รายละเอียดโจทย์

สร้างเว็บไซต์สำหรับร้านอาหารที่มีชื่อว่า **"ร้านอาหารอร่อย"** โดยเว็บไซต์ต้องสามารถแสดงผลได้อย่างเหมาะสมบนอุปกรณ์ทั้ง 3 ขนาด:
- 📱 **Mobile** (0-767px)
- 💻 **Tablet** (768-1023px)  
- 🖥️ **Desktop** (1024px ขึ้นไป)

---

## 📄 โครงสร้างเว็บไซต์ที่ต้องมี

### 1. Navigation Bar (20 คะแนน)
- Logo ร้านอาหาร
- เมนู: หน้าหลัก | เมนูอาหาร | เกี่ยวกับเรา | ติดต่อ
- **Mobile**: แสดงเป็น Hamburger Menu
- **Tablet/Desktop**: แสดงเป็นแถบเมนูแนวนอน

### 2. Hero Section (15 คะแนน)
- หัวข้อใหญ่ชื่อร้านอาหาร
- คำโปรย (Tagline) ของร้าน เช่น "อาหารไทยต้นตำรับ อร่อยทุกคำ"
- ปุ่ม Call-to-Action เช่น "ดูเมนูอาหาร" หรือ "สั่งอาหารเดลิเวอรี่"
- รูปภาพหรือ Icon แทนรูปภาพ

### 3. Menu Section (แสดงเมนูอาหาร) (25 คะแนน)
แสดงการ์ดเมนูอาหารอย่างน้อย **6 รายการ** โดยแต่ละการ์ดมี:
- รูปภาพอาหาร (หรือ Icon/Emoji แทนรูป)
- ชื่อเมนู
- รายละเอียดสั้นๆ
- ราคา
- ปุ่ม "สั่งอาหาร"

**การจัด Layout:**
- **Mobile**: 1 คอลัมน์ต่อแถว
- **Tablet**: 2 คอลัมน์ต่อแถว
- **Desktop**: 3 คอลัมน์ต่อแถว

### 4. About Section (10 คะแนน)
- ข้อมูลเกี่ยวกับร้าน
- ประวัติความเป็นมา
- จุดเด่นของร้าน
- **Responsive Layout**: 
  - Mobile: รูปภาพอยู่บน ข้อความอยู่ล่าง
  - Tablet/Desktop: รูปภาพอยู่ซ้าย ข้อความอยู่ขวา (หรือในทางกลับกัน)

### 5. Contact Section (10 คะแนน)
- ชื่อร้าน
- ที่อยู่
- เบอร์โทรศัพท์
- อีเมล
- เวลาเปิด-ปิด
- Link Social Media

### 6. Footer (5 คะแนน)
- Copyright text
- Social Media Icons/Links
- ข้อมูลเพิ่มเติม

---

## 🎨 ข้อกำหนดด้าน Design (15 คะแนน)

### สี (Color Scheme)
- เลือกใช้สีที่เข้ากับธีมร้านอาหาร
- ควรมีสีหลัก (Primary Color) และสีรอง (Secondary Color)
- สีต้องเข้ากันและอ่านง่าย

### Typography
- ใช้ Google Fonts (แนะนำ: Kanit สำหรับภาษาไทย)
- ขนาดตัวอักษรต้องอ่านง่ายบนทุกอุปกรณ์
- Mobile: font-size เล็กกว่า Desktop

### Spacing & Layout
- ใช้ padding และ margin ที่เหมาะสม
- เว้นระยะห่างระหว่าง sections
- ไม่ให้เนื้อหาแน่นเกินไปหรือห่างเกินไป

### Images
- รูปภาพต้องเป็น Responsive (`max-width: 100%`, `height: auto`)
- ไม่บิดเบี้ยวบนหน้าจอขนาดต่างๆ

---

## 💻 ข้อกำหนดทางเทคนิค

### Required HTML Elements
```html
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ร้านอาหารอร่อย - อาหารไทยต้นตำรับ</title>
    <!-- Google Fonts -->
    <!-- CSS Styles -->
</head>
<body>
    <!-- Navigation -->
    <!-- Hero Section -->
    <!-- Menu Section -->
    <!-- About Section -->
    <!-- Contact Section -->
    <!-- Footer -->
    <!-- JavaScript (ถ้าใช้) -->
</body>
</html>
```

### Required CSS - Viewport Meta Tag
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

### Required CSS - Media Queries (ต้องมีครบ 3 Breakpoints)
```css
/* Base styles for Mobile (0-767px) - ไม่ต้องใส่ media query */

/* Tablet (768px and up) */
@media (min-width: 768px) {
    /* CSS for Tablet */
}

/* Desktop (1024px and up) */
@media (min-width: 1024px) {
    /* CSS for Desktop */
}
```

### Required CSS - Flexible Units
- ใช้หน่วย %, rem, em, vw, vh แทน px สำหรับ layout หลัก
- Container ควรใช้ `max-width` เพื่อจำกัดความกว้าง

### JavaScript (Optional แต่ได้คะแนนพิเศษ)
- Hamburger menu toggle (เปิด-ปิดเมนูบน mobile)
- Smooth scroll
- Active link on scroll

---

## ✅ Checklist สำหรับนักศึกษา

### HTML Structure (ถูกต้องครบถ้วน)
- [ ] มี `<!DOCTYPE html>` และ Viewport Meta Tag
- [ ] มี Semantic HTML Tags (`<header>`, `<nav>`, `<section>`, `<footer>`)
- [ ] โครงสร้าง HTML เป็นระเบียบและมี indentation ที่ดี
- [ ] มี comment อธิบายแต่ละ section

### CSS Styling
- [ ] ใช้ Google Fonts
- [ ] มี CSS Reset (`* { margin: 0; padding: 0; box-sizing: border-box; }`)
- [ ] ใช้ CSS Variables (`:root`) สำหรับสี (ถ้าเป็นไปได้)
- [ ] มี Media Queries ครบ 3 breakpoints
- [ ] ใช้ Flexbox หรือ Grid สำหรับ layout
- [ ] มี Hover effects สำหรับปุ่มและลิงก์
- [ ] มี Transition/Animation (smooth effects)

### Responsive Design
- [ ] เว็บไซต์แสดงผลได้ดีบน Mobile (กว้างน้อยกว่า 768px)
- [ ] เว็บไซต์แสดงผลได้ดีบน Tablet (768-1023px)
- [ ] เว็บไซต์แสดงผลได้ดีบน Desktop (1024px ขึ้นไป)
- [ ] Navigation เปลี่ยนเป็น Hamburger Menu บน Mobile
- [ ] จำนวนคอลัมน์ของ Menu Cards เปลี่ยนตาม breakpoint
- [ ] ขนาดตัวอักษรและ spacing ปรับตามขนาดหน้าจอ
- [ ] รูปภาพเป็น responsive และไม่บิดเบี้ยว

### Code Quality
- [ ] Code เขียนเป็นระเบียบ มี indentation ถูกต้อง
- [ ] มี comment อธิบายส่วนสำคัญ (ภาษาไทยหรือภาษาอังกฤษ)
- [ ] CSS จัดกลุ่มตาม component หรือ section
- [ ] ตั้งชื่อ class อย่างมีความหมาย (เช่น `.menu-card`, `.hero-title`)

### Testing
- [ ] ทดสอบบน Chrome DevTools Device Mode
- [ ] ทดสอบบนอุปกรณ์จริง (มือถือ/แท็บเล็ต) ถ้าเป็นไปได้
- [ ] ทดสอบปรับขนาดหน้าต่าง browser
- [ ] ตรวจสอบว่าปุ่มและลิงก์ทำงานได้

---

## 📊 เกณฑ์การให้คะแนน (100 คะแนน)

### 1. Navigation Bar (20 คะแนน)

| คะแนน | เกณฑ์การให้คะแนน |
|-------|------------------|
| **18-20** | **ดีเยี่ยม (Excellent)**<br>• Navigation สมบูรณ์และสวยงาม<br>• มี Hamburger Menu บน Mobile ที่ทำงานได้<br>• Desktop แสดงเป็นแถบเมนูแนวนอน<br>• มี Active state และ Hover effects<br>• Sticky navigation (ติดด้านบน)<br>• Smooth animation |
| **15-17** | **ดี (Good)**<br>• Navigation ครบถ้วนและทำงานได้<br>• มี Hamburger Menu บน Mobile<br>• เปลี่ยน layout ตาม breakpoint<br>• มี Hover effects พื้นฐาน<br>• อาจขาด animation บางส่วน |
| **12-14** | **พอใช้ (Fair)**<br>• Navigation ทำงานได้แต่ไม่สมบูรณ์<br>• Hamburger Menu มีแต่อาจมีปัญหา<br>• Layout เปลี่ยนได้แต่ไม่ smooth<br>• ขาด Hover effects หรือ animation<br>• Design ยังไม่ค่อยสวย |
| **0-11** | **ต้องปรับปรุง (Needs Improvement)**<br>• Navigation ไม่สมบูรณ์<br>• ไม่มี Hamburger Menu บน Mobile<br>• ไม่เปลี่ยน layout ตาม breakpoint<br>• ไม่มี Hover effects<br>• มีปัญหาในการใช้งาน |

### 2. Hero Section (15 คะแนน)

| คะแนน | เกณฑ์การให้คะแนน |
|-------|------------------|
| **14-15** | **ดีเยี่ยม (Excellent)**<br>• Design สวยงามและน่าสนใจ<br>• มีหัวข้อ tagline และปุ่ม CTA<br>• Layout responsive บนทุกอุปกรณ์<br>• มี Animation หรือ visual effects<br>• Typography และ spacing เหมาะสม<br>• สีสันสวยงาม |
| **12-13** | **ดี (Good)**<br>• มีครบทุก elements (หัวข้อ, tagline, ปุ่ม)<br>• Layout ปรับตามขนาดหน้าจอได้<br>• Design ดูดีแต่ยังไม่โดดเด่น<br>• Spacing อาจไม่สมดุล<br>• อาจขาด animation |
| **10-11** | **พอใช้ (Fair)**<br>• มี elements หลักแต่ไม่ครบ<br>• Layout responsive แต่ไม่ค่อยสวย<br>• Typography หรือ spacing ไม่เหมาะสม<br>• สีสันธรรมดาหรือไม่เข้ากัน<br>• ขาด visual appeal |
| **0-9** | **ต้องปรับปรุง (Needs Improvement)**<br>• ขาด elements สำคัญ<br>• ไม่ responsive<br>• Design ไม่น่าสนใจ<br>• Typography และ spacing มีปัญหา<br>• สีสันไม่เข้ากัน |

### 3. Menu Section (25 คะแนน)

| คะแนน | เกณฑ์การให้คะแนน |
|-------|------------------|
| **23-25** | **ดีเยี่ยม (Excellent)**<br>• แสดงเมนูอาหารครบ 6 รายการ<br>• Cards สวยงามและเป็นระเบียบ<br>• Mobile: 1 คอลัมน์, Tablet: 2 คอลัมน์, Desktop: 3 คอลัมน์<br>• มี Hover effects และ transition smooth<br>• รูปภาพ/Icon สวยงามและ responsive<br>• Typography และ spacing สมบูรณ์<br>• มีปุ่ม "สั่งอาหาร" ที่สวยและใช้งานได้ |
| **20-22** | **ดี (Good)**<br>• แสดงเมนูอาหารครบ 6 รายการ<br>• Layout เปลี่ยนตาม breakpoint ถูกต้อง<br>• Cards ดูดีแต่ยังไม่โดดเด่น<br>• มี Hover effects พื้นฐาน<br>• Spacing อาจไม่สมดุล<br>• รูปภาพ responsive |
| **17-19** | **พอใช้ (Fair)**<br>• มีเมนูอาหารแต่อาจไม่ครบ 6 รายการ<br>• Layout เปลี่ยนได้แต่อาจมีปัญหา<br>• Cards design ธรรมดา<br>• ขาด Hover effects<br>• Spacing ไม่เหมาะสม<br>• รูปภาพอาจบิดเบี้ยว |
| **0-16** | **ต้องปรับปรุง (Needs Improvement)**<br>• มีเมนูไม่ครบ<br>• Layout ไม่เปลี่ยนตาม breakpoint<br>• Cards ไม่เป็นระเบียบ<br>• ไม่มี Hover effects<br>• รูปภาพมีปัญหา<br>• Design ไม่น่าสนใจ |

### 4. About Section (10 คะแนน)

| คะแนน | เกณฑ์การให้คะแนน |
|-------|------------------|
| **9-10** | **ดีเยี่ยม (Excellent)**<br>• เนื้อหาครบถ้วนและน่าสนใจ<br>• Layout responsive สมบูรณ์<br>• Mobile: stack แนวตั้ง, Desktop: แนวนอน<br>• Typography และ spacing ดี<br>• มี visual element เสริม |
| **7-8** | **ดี (Good)**<br>• เนื้อหาครบ<br>• Layout เปลี่ยนตาม breakpoint<br>• Spacing พอใช้<br>• อาจขาด visual element |
| **5-6** | **พอใช้ (Fair)**<br>• เนื้อหาไม่ครบ<br>• Layout responsive แต่ไม่สวย<br>• Spacing ไม่เหมาะสม |
| **0-4** | **ต้องปรับปรุง (Needs Improvement)**<br>• เนื้อหาขาดหายไป<br>• ไม่ responsive<br>• Design มีปัญหา |

### 5. Contact Section (10 คะแนน)

| คะแนน | เกณฑ์การให้คะแนน |
|-------|------------------|
| **9-10** | **ดีเยี่ยม (Excellent)**<br>• ข้อมูลติดต่อครบถ้วน<br>• แสดงผลดีบนทุกอุปกรณ์<br>• มี Icons หรือ visual elements<br>• Layout เป็นระเบียบ |
| **7-8** | **ดี (Good)**<br>• ข้อมูลติดต่อครบ<br>• Responsive ได้<br>• อาจขาด Icons |
| **5-6** | **พอใช้ (Fair)**<br>• ข้อมูลไม่ครบ<br>• Responsive แต่ไม่สวย |
| **0-4** | **ต้องปรับปรุง (Needs Improvement)**<br>• ข้อมูลไม่ครบ<br>• ไม่ responsive |

### 6. Footer (5 คะแนน)

| คะแนน | เกณฑ์การให้คะแนน |
|-------|------------------|
| **5** | **ดีเยี่ยม**: Footer สมบูรณ์ มี Copyright, Social Links, responsive |
| **4** | **ดี**: Footer ครบแต่ขาด Social Links หรือบาง elements |
| **3** | **พอใช้**: Footer มีแต่ไม่ครบถ้วน, responsive ได้บ้าง |
| **0-2** | **ต้องปรับปรุง**: Footer ไม่สมบูรณ์ หรือไม่มีเลย |

### 7. Design และความสวยงาม (15 คะแนน)

| คะแนน | เกณฑ์การให้คะแนน |
|-------|------------------|
| **14-15** | **ดีเยี่ยม (Excellent)**<br>• Color scheme สวยงามและเข้ากัน<br>• Typography เหมาะสมทุกขนาดหน้าจอ<br>• Spacing และ layout สมดุลดี<br>• มี visual hierarchy ชัดเจน<br>• Hover effects และ transitions smooth<br>• Overall design มืออาชีพ |
| **12-13** | **ดี (Good)**<br>• สีสันใช้ได้ดีแต่อาจไม่โดดเด่น<br>• Typography เหมาะสม<br>• Spacing ส่วนใหญ่ดี<br>• มี effects พื้นฐาน<br>• Design ดูดีโดยรวม |
| **10-11** | **พอใช้ (Fair)**<br>• สีสันธรรมดา<br>• Typography บางส่วนไม่เหมาะสม<br>• Spacing ไม่สมดุล<br>• ขาด effects<br>• Design พอใช้ได้ |
| **0-9** | **ต้องปรับปรุง (Needs Improvement)**<br>• สีสันไม่เข้ากัน<br>• Typography มีปัญหา<br>• Spacing แน่นหรือห่างเกินไป<br>• ไม่มี effects<br>• Design ไม่น่าสนใจ |

---

## 📝 วิธีการส่งงาน

### ไฟล์ที่ต้องส่ง:
1. **restaurant-responsive.html** - ไฟล์ HTML เดียว (รวม CSS และ JS ไว้ด้วยกัน)
2. หรือแยกเป็น:
   - **index.html** - ไฟล์ HTML
   - **styles.css** - ไฟล์ CSS
   - **script.js** - ไฟล์ JavaScript (ถ้ามี)

### การตรวจสอบก่อนส่ง:
1. เปิดไฟล์ใน Visual Studio Code
2. ใช้ Live Server หรือเปิดไฟล์ในบราวเซอร์
3. กด F12 เพื่อเปิด DevTools
4. คลิก Toggle Device Toolbar (Ctrl+Shift+M)
5. ทดสอบบนขนาดหน้าจอต่างๆ:
   - Mobile: 375px, 414px
   - Tablet: 768px, 834px
   - Desktop: 1024px, 1440px
6. ตรวจสอบให้แน่ใจว่า:
   - Navigation เปลี่ยนเป็น Hamburger Menu บน Mobile
   - Menu cards จัด layout ถูกต้องตาม breakpoint
   - ทุก section แสดงผลได้ดีบนทุกขนาด
   - ไม่มีรูปบิดเบี้ยวหรือ overflow

---

## 💡 เคล็ดลับและคำแนะนำ

### 1. เริ่มจาก Mobile First
```css
/* เริ่มเขียน CSS สำหรับ Mobile ก่อน (ไม่ต้องใส่ media query) */
.menu-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
}

/* จากนั้นค่อยปรับสำหรับ Tablet */
@media (min-width: 768px) {
    .menu-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

/* และ Desktop */
@media (min-width: 1024px) {
    .menu-grid {
        grid-template-columns: repeat(3, 1fr);
    }
}
```

### 2. ใช้ CSS Variables สำหรับสี
```css
:root {
    --primary-color: #ff6b6b;
    --secondary-color: #4ecdc4;
    --text-dark: #2d3748;
    --text-light: #718096;
}

.hero {
    background: var(--primary-color);
    color: white;
}
```

### 3. Flexbox และ Grid
```css
/* ใช้ Flexbox สำหรับ Navigation */
.nav-menu {
    display: flex;
    gap: 20px;
}

/* ใช้ Grid สำหรับ Menu Cards */
.menu-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}
```

### 4. Responsive Images
```css
img {
    max-width: 100%;
    height: auto;
    display: block;
}
```

### 5. Container Width
```css
.container {
    width: 90%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}
```

### 6. Smooth Transitions
```css
.btn {
    transition: all 0.3s ease;
}

.btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
}
```

---

## 🎨 ตัวอย่าง Color Schemes

### Scheme 1: Orange & Red (Thai Food)
```css
:root {
    --primary: #ff6b6b;
    --secondary: #ff8e53;
    --dark: #2d3748;
    --light: #f7fafc;
}
```

### Scheme 2: Green & Yellow (Fresh Food)
```css
:root {
    --primary: #51cf66;
    --secondary: #ffd93d;
    --dark: #2d3748;
    --light: #f7fafc;
}
```

### Scheme 3: Blue & Purple (Modern)
```css
:root {
    --primary: #667eea;
    --secondary: #764ba2;
    --dark: #2d3748;
    --light: #f7fafc;
}
```

---

## ❓ คำถามที่พบบ่อย (FAQ)

**Q1: ต้องใช้รูปภาพจริงหรือไม่?**  
A: ไม่จำเป็น สามารถใช้ Emoji, Icons หรือ Placeholder สีแทนได้

**Q2: ต้องทำ Hamburger Menu ให้ทำงานได้จริงหรือไม่?**  
A: ต้องทำให้ทำงานได้ (ใช้ JavaScript) เพื่อให้ได้คะแนนเต็ม แต่ถ้าทำไม่ได้จะได้คะแนนบางส่วน

**Q3: สามารถใช้ Framework เช่น Bootstrap ได้หรือไม่?**  
A: **ไม่ได้** ต้องเขียน CSS เองทั้งหมด เพื่อฝึกทักษะ Responsive Design

**Q4: ต้องมีกี่หน้า (pages)?**  
A: 1 หน้าเดียวเท่านั้น (Single Page) แต่มีหลาย sections

**Q5: ถ้าไม่มี JavaScript จะได้คะแนนไหม?**  
A: ได้ แต่จะได้คะแนนลดลง โดยเฉพาะส่วน Navigation (ถ้า Hamburger Menu ไม่ทำงาน)

**Q6: ต้องเขียน comment ภาษาไทยหรือภาษาอังกฤษ?**  
A: ใช้ภาษาไหนก็ได้ แต่ต้องเขียน comment อธิบายส่วนสำคัญ

**Q7: ต้องใช้ Google Fonts หรือไม่?**  
A: แนะนำให้ใช้ (โดยเฉพาะ Kanit สำหรับภาษาไทย) เพื่อให้ typography สวยงาม

---

## 🏆 เกณฑ์การผ่าน

- **คะแนน 80-100**: ดีเยี่ยม (A)
- **คะแนน 70-79**: ดีมาก (B+)
- **คะแนน 60-69**: ดี (B)
- **คะแนน 50-59**: พอใช้ (C)
- **คะแนนต่ำกว่า 50**: ต้องส่งใหม่

---

## 📚 แหล่งข้อมูลเพิ่มเติม

- [MDN Web Docs - Responsive Design](https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Responsive_Design)
- [CSS-Tricks - A Complete Guide to Flexbox](https://css-tricks.com/snippets/css/a-guide-to-flexbox/)
- [CSS-Tricks - A Complete Guide to Grid](https://css-tricks.com/snippets/css/complete-guide-grid/)
- [Google Fonts](https://fonts.google.com/)

---

**หมายเหตุ**: ให้นักศึกษาทำงานด้วยความซื่อสัตย์ อย่าลอกเลียนแบบงานผู้อื่น การทำความเข้าใจและฝึกปฏิบัติจริงจะช่วยให้มีทักษะที่แข็งแกร่งในระยะยาว

**กำหนดส่ง**: [ระบุวันที่]  
**ส่งงานที่**: [ระบุช่องทางการส่งงาน]

---

**ขอให้โชคดีกับการทำแบบฝึกหัดครับ! 🚀**
