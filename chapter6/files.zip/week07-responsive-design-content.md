# สัปดาห์ที่ 7: Responsive Web Design & Media Queries

## 🎯 วัตถุประสงค์การเรียนรู้ (Learning Objectives)

เมื่อจบบทเรียนนี้ นักศึกษาจะสามารถ:

1. **อธิบาย** แนวคิดและความสำคัญของ Responsive Web Design
2. **ใช้งาน** Viewport Meta Tag และเข้าใจการทำงาน
3. **เขียน** Media Queries เพื่อปรับแต่งการแสดงผลตามขนาดหน้าจอ
4. **กำหนด** Breakpoints ที่เหมาะสมสำหรับอุปกรณ์ต่างๆ
5. **สร้าง** เว็บไซต์ที่ตอบสนองต่อหลายขนาดหน้าจอ (Mobile, Tablet, Desktop)
6. **ปรับใช้** เทคนิค Mobile-First และ Desktop-First Approach

---

## 📚 เนื้อหาทฤษฎี

### 1. Responsive Web Design คือะไร?

**Responsive Web Design (RWD)** คือการออกแบบเว็บไซต์ให้สามารถปรับตัว (adapt) และแสดงผลได้อย่างเหมาะสมบนอุปกรณ์และขนาดหน้าจอที่แตกต่างกัน

**ความสำคัญ:**
- ผู้ใช้งานเข้าถึงเว็บผ่านอุปกรณ์ที่หลากหลาย (มือถือ, แท็บเล็ต, คอมพิวเตอร์)
- ปรับปรุงประสบการณ์ผู้ใช้ (User Experience - UX)
- เพิ่มอันดับใน SEO (Google ให้ความสำคัญกับ mobile-friendly sites)
- ลดต้นทุนในการดูแลรักษา (ไม่ต้องทำ mobile version แยก)

**หลักการสำคัญ 3 ประการ:**
1. **Flexible Grids** - ใช้หน่วยแบบ relative (%, em, rem, vw, vh)
2. **Flexible Images** - รูปภาพปรับขนาดตามพื้นที่
3. **Media Queries** - กำหนด CSS ที่แตกต่างกันตามเงื่อนไข

---

### 2. Viewport และ Meta Tag

**Viewport** คือพื้นที่ที่ผู้ใช้มองเห็นบนหน้าจอ

```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

**คำอธิบาย:**
- `width=device-width` - กำหนดความกว้างของ viewport ให้เท่ากับความกว้างของอุปกรณ์
- `initial-scale=1.0` - กำหนดระดับการซูมเริ่มต้นเป็น 100%

**ตัวเลือกเพิ่มเติม:**
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, minimum-scale=1.0, user-scalable=yes">
```

---

### 3. Media Queries พื้นฐาน

**Media Query** คือเงื่อนไข CSS ที่ใช้ตรวจสอบคุณสมบัติของอุปกรณ์ เช่น ความกว้างหน้าจอ, ความสูง, orientation

**รูปแบบพื้นฐาน:**
```css
@media media-type and (condition) {
    /* CSS rules */
}
```

**ตัวอย่าง:**
```css
/* สำหรับหน้าจอที่กว้างไม่เกิน 768px */
@media screen and (max-width: 768px) {
    .container {
        width: 100%;
        padding: 10px;
    }
}

/* สำหรับหน้าจอที่กว้างมากกว่า 1024px */
@media screen and (min-width: 1024px) {
    .container {
        max-width: 1200px;
        margin: 0 auto;
    }
}
```

**Media Types ที่นิยม:**
- `screen` - สำหรับหน้าจอคอมพิวเตอร์, แท็บเล็ต, มือถือ
- `print` - สำหรับการพิมพ์
- `all` - สำหรับทุกอุปกรณ์ (ค่าเริ่มต้น)

**Conditions ที่นิยม:**
- `min-width` - ความกว้างขั้นต่ำ
- `max-width` - ความกว้างสูงสุด
- `orientation: portrait` - แนวตั้ง
- `orientation: landscape` - แนวนอน

---

### 4. Breakpoints มาตรฐาน

**Breakpoints** คือจุดที่เรากำหนดให้เว็บไซต์เปลี่ยนรูปแบบการแสดงผล

**Breakpoints ที่นิยมใช้:**

```css
/* Extra Small Devices (Phones) */
/* 0px - 575px */

/* Small Devices (Phones, Landscape) */
@media (min-width: 576px) { }

/* Medium Devices (Tablets) */
@media (min-width: 768px) { }

/* Large Devices (Desktops) */
@media (min-width: 992px) { }

/* Extra Large Devices (Large Desktops) */
@media (min-width: 1200px) { }

/* Extra Extra Large Devices */
@media (min-width: 1400px) { }
```

**Breakpoints ทั่วไป (ง่ายต่อการจำ):**
```css
/* Mobile First Approach */
/* Mobile: 0-767px (ไม่ต้องเขียน media query) */

/* Tablet: 768px and up */
@media (min-width: 768px) { }

/* Desktop: 1024px and up */
@media (min-width: 1024px) { }

/* Large Desktop: 1440px and up */
@media (min-width: 1440px) { }
```

---

### 5. Mobile-First vs Desktop-First Approach

#### 🔵 Mobile-First Approach (แนะนำ)

เริ่มออกแบบสำหรับมือถือก่อน แล้วค่อยขยายไปหน้าจอใหญ่

**ข้อดี:**
- ทำให้มุ่งเน้นเนื้อหาสำคัญ (Content First)
- Performance ดีกว่า (โหลดเร็วบนมือถือ)
- ง่ายต่อการพัฒนา (Progressive Enhancement)

**ตัวอย่าง:**
```css
/* Base styles สำหรับ Mobile (ไม่ต้องใส่ media query) */
.container {
    width: 100%;
    padding: 15px;
}

.column {
    width: 100%;
    margin-bottom: 20px;
}

/* Tablet และใหญ่ขึ้น */
@media (min-width: 768px) {
    .column {
        width: 48%;
        float: left;
        margin-right: 2%;
    }
}

/* Desktop และใหญ่ขึ้น */
@media (min-width: 1024px) {
    .container {
        max-width: 1200px;
        margin: 0 auto;
    }
    
    .column {
        width: 31%;
        margin-right: 2%;
    }
}
```

#### 🔴 Desktop-First Approach

เริ่มออกแบบสำหรับ Desktop ก่อน แล้วค่อยปรับให้เล็กลง

**ตัวอย่าง:**
```css
/* Base styles สำหรับ Desktop */
.container {
    max-width: 1200px;
    margin: 0 auto;
}

.column {
    width: 31%;
    float: left;
    margin-right: 2%;
}

/* Tablet และเล็กลง */
@media (max-width: 1023px) {
    .column {
        width: 48%;
    }
}

/* Mobile และเล็กลง */
@media (max-width: 767px) {
    .column {
        width: 100%;
        float: none;
        margin-right: 0;
    }
}
```

---

### 6. Flexible Units (หน่วยที่ยืดหยุ่น)

**หน่วยแบบ Relative:**
- `%` - เปอร์เซ็นต์ของ parent element
- `em` - สัมพันธ์กับ font-size ของตัวเอง
- `rem` - สัมพันธ์กับ font-size ของ root (html)
- `vw` - 1% ของ viewport width
- `vh` - 1% ของ viewport height
- `vmin` - 1% ของ viewport ด้านที่เล็กกว่า
- `vmax` - 1% ของ viewport ด้านที่ใหญ่กว่า

**ตัวอย่างการใช้งาน:**
```css
.container {
    width: 90%;              /* ยืดหยุ่นตามขนาดจอ */
    max-width: 1200px;       /* จำกัดความกว้างสูงสุด */
    padding: 2rem;           /* ระยะห่างสัมพันธ์กับ font-size */
}

.hero {
    height: 100vh;           /* เต็มความสูงหน้าจอ */
    font-size: 5vw;          /* ขนาดตัวอักษรตามขนาดจอ */
}
```

---

### 7. Responsive Images

**เทคนิคพื้นฐาน:**
```css
img {
    max-width: 100%;
    height: auto;
    display: block;
}
```

**การใช้ srcset สำหรับรูปภาพหลายขนาด:**
```html
<img 
    src="image-small.jpg"
    srcset="image-small.jpg 480w,
            image-medium.jpg 768w,
            image-large.jpg 1200w"
    sizes="(max-width: 480px) 100vw,
           (max-width: 768px) 80vw,
           1200px"
    alt="Responsive Image">
```

**Picture Element:**
```html
<picture>
    <source media="(max-width: 767px)" srcset="mobile.jpg">
    <source media="(max-width: 1023px)" srcset="tablet.jpg">
    <img src="desktop.jpg" alt="Responsive Image">
</picture>
```

---

### 8. Common Patterns (รูปแบบที่นิยมใช้)

#### 8.1 Responsive Navigation
```css
/* Mobile: Hamburger Menu */
.nav-toggle {
    display: block;
}

.nav-menu {
    display: none;
}

.nav-menu.active {
    display: block;
}

/* Desktop: Horizontal Menu */
@media (min-width: 768px) {
    .nav-toggle {
        display: none;
    }
    
    .nav-menu {
        display: flex;
    }
}
```

#### 8.2 Responsive Grid
```css
.grid {
    display: grid;
    grid-template-columns: 1fr;        /* Mobile: 1 column */
    gap: 20px;
}

@media (min-width: 768px) {
    .grid {
        grid-template-columns: repeat(2, 1fr);  /* Tablet: 2 columns */
    }
}

@media (min-width: 1024px) {
    .grid {
        grid-template-columns: repeat(3, 1fr);  /* Desktop: 3 columns */
    }
}
```

#### 8.3 Responsive Typography
```css
/* Mobile */
body {
    font-size: 16px;
    line-height: 1.5;
}

h1 {
    font-size: 2rem;        /* 32px */
}

h2 {
    font-size: 1.5rem;      /* 24px */
}

/* Desktop */
@media (min-width: 1024px) {
    body {
        font-size: 18px;
    }
    
    h1 {
        font-size: 3rem;    /* 54px */
    }
    
    h2 {
        font-size: 2rem;    /* 36px */
    }
}
```

---

## 💡 เทคนิคและ Best Practices

### 1. ใช้ Mobile-First Approach
✅ เริ่มจาก mobile แล้วใช้ `min-width`  
❌ หลีกเลี่ยงการใช้ `max-width` มากเกินไป

### 2. จำกัดจำนวน Breakpoints
✅ ใช้ 3-4 breakpoints หลัก  
❌ อย่าสร้าง breakpoint มากเกินไปจนยากต่อการดูแล

### 3. ทดสอบบนอุปกรณ์จริง
✅ ทดสอบบนมือถือและแท็บเล็ตจริง  
✅ ใช้ Chrome DevTools Device Mode  
✅ ทดสอบ landscape และ portrait

### 4. ใช้ Relative Units
✅ ใช้ %, em, rem, vw, vh  
❌ หลีกเลี่ยง px สำหรับ layout หลัก

### 5. เตรียมเนื้อหาที่สำคัญก่อน
✅ แสดงเนื้อหาสำคัญบน mobile  
✅ Progressive Enhancement สำหรับหน้าจอใหญ่

### 6. ใช้ Flexbox และ Grid
✅ ใช้ modern layout techniques  
✅ ลดการใช้ float และ positioning

---

## 🎨 Design Considerations

### 1. Touch Targets
- ปุ่มและลิงก์ควรมีขนาดอย่างน้อย **44x44px** บนมือถือ
- เว้นระยะห่างระหว่างปุ่มเพียงพอ

### 2. Typography
- ขนาดตัวอักษรอย่างน้อย **16px** สำหรับเนื้อหาหลัก
- Line height ควรอยู่ที่ **1.5-1.6** เพื่อความอ่านง่าย
- จำกัดความกว้างของบรรทัดที่ **60-70 ตัวอักษร**

### 3. Images และ Media
- ใช้รูปภาพที่มีขนาดเหมาะสมกับอุปกรณ์
- พิจารณาใช้ lazy loading สำหรับรูปภาพ
- ทำให้ video responsive ด้วย

### 4. Performance
- โหลดเฉพาะทรัพยากรที่จำเป็น
- ใช้ CSS แทน JavaScript เมื่อเป็นไปได้
- Optimize รูปภาพให้มีขนาดเล็ก

---

## 📋 สรุป

**Responsive Web Design** เป็นมาตรฐานในการพัฒนาเว็บสมัยใหม่:

✅ **ต้องมี** Viewport Meta Tag  
✅ **ใช้** Media Queries เพื่อปรับ layout  
✅ **เลือกใช้** Mobile-First Approach  
✅ **กำหนด** Breakpoints ที่เหมาะสม  
✅ **ใช้** Flexible Units (%, rem, vw, vh)  
✅ **ทำให้** Images และ Media responsive  
✅ **ทดสอบ** บนหลายขนาดหน้าจอ  

---

## 📖 แหล่งข้อมูลเพิ่มเติม

- [MDN: Responsive Design](https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Responsive_Design)
- [Google Web Fundamentals: Responsive Web Design](https://developers.google.com/web/fundamentals/design-and-ux/responsive)
- [CSS-Tricks: A Complete Guide to Flexbox](https://css-tricks.com/snippets/css/a-guide-to-flexbox/)
- [CSS-Tricks: A Complete Guide to Grid](https://css-tricks.com/snippets/css/complete-guide-grid/)
