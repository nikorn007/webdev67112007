# 📚 สรุปเอกสารสัปดาห์ที่ 7: Responsive Web Design & Media Queries

## 📋 รายการไฟล์ทั้งหมด

จัดทำเมื่อ: 8 ธันวาคม 2025  
หัวข้อ: Responsive Web Design & Media Queries  
ระดับ: ปริญญาตรี ชั้นปีที่ 1-2 (เหมาะกับผู้เริ่มต้น)

---

## 📖 1. เอกสารเนื้อหาหลัก

**ไฟล์:** `week07-responsive-design-content.md`

### เนื้อหาที่ครอบคลุม:
- วัตถุประสงค์การเรียนรู้ (Learning Objectives)
- ความหมายและความสำคัญของ Responsive Web Design
- Viewport และ Meta Tag
- Media Queries พื้นฐาน
- Breakpoints มาตรฐาน
- Mobile-First vs Desktop-First Approach
- Flexible Units (%, em, rem, vw, vh)
- Responsive Images
- Common Patterns (Navigation, Grid, Typography)
- เทคนิคและ Best Practices
- Design Considerations

### การใช้งาน:
- ใช้เป็นเอกสารประกอบการสอน
- ให้นักศึกษาอ่านก่อนเรียน
- Reference สำหรับทำแบบฝึกหัด

---

## 💻 2. ตัวอย่างโค้ดที่สมบูรณ์ (4 ไฟล์)

### 2.1 ตัวอย่างที่ 1: Basic Responsive Layout
**ไฟล์:** `example1-basic-responsive.html`

**จุดเด่น:**
- แสดง Device Indicator บอกขนาดหน้าจอปัจจุบัน
- Grid Layout ที่เปลี่ยนจำนวนคอลัมน์ตาม breakpoint
- Mobile: 1 คอลัมน์
- Tablet: 2 คอลัมน์
- Desktop: 3 คอลัมน์
- Large Desktop: 4 คอลัมน์

**เหมาะสำหรับ:**
- แนะนำแนวคิด Responsive Design
- อธิบาย Breakpoints
- สาธิตการเปลี่ยน Layout

### 2.2 ตัวอย่างที่ 2: Responsive Card Grid
**ไฟล์:** `example2-responsive-cards.html`

**จุดเด่น:**
- Product Showcase ที่สวยงาม
- Card Layout พร้อม Hover Effects
- Stats Section และ Features Grid
- Breakpoint Info แสดง real-time
- Gradient และ Shadow Effects

**เหมาะสำหรับ:**
- สอนการจัด Layout Cards
- แสดง Hover Effects
- Design Patterns สำหรับ E-Commerce

### 2.3 ตัวอย่างที่ 3: Responsive Navigation
**ไฟล์:** `example3-responsive-navigation.html`

**จุดเด่น:**
- Hamburger Menu บน Mobile
- Horizontal Navigation บน Desktop
- Sticky Navigation
- Smooth Scroll
- Active Link on Scroll
- Animation ของ Hamburger Icon

**เหมาะสำหรับ:**
- สอนการทำ Responsive Navigation
- JavaScript พื้นฐาน (Menu Toggle)
- Animation และ Transitions

### 2.4 ตัวอย่างที่ 4: Complete Portfolio Website
**ไฟล์:** `example4-complete-portfolio.html`

**จุดเด่น:**
- เว็บไซต์ Portfolio ครบวงจร
- รวมเทคนิคที่เรียนทั้งหมด
- Hero Section, About, Services, Portfolio, Contact
- Form Design
- Smooth Animations
- Professional Design

**เหมาะสำหรับ:**
- สรุปและรวมเทคนิคทั้งหมด
- เป็นแนวทางสำหรับทำ Project
- แสดงตัวอย่าง Production-Ready Website

---

## 📝 3. แบบฝึกหัด

**ไฟล์:** `week07-exercise-restaurant.md`

### โจทย์:
สร้างเว็บไซต์ร้านอาหาร "ร้านอาหารอร่อย" แบบ Responsive

### โครงสร้างที่ต้องมี:
1. **Navigation Bar (20 คะแนน)**
   - Logo และเมนู
   - Hamburger Menu บน Mobile
   
2. **Hero Section (15 คะแนน)**
   - หัวข้อ, Tagline, CTA Button
   
3. **Menu Section (25 คะแนน)**
   - การ์ดเมนูอาหาร 6 รายการ
   - Layout: 1/2/3 คอลัมน์ตาม breakpoint
   
4. **About Section (10 คะแนน)**
   - ข้อมูลร้าน
   - Responsive Layout
   
5. **Contact Section (10 คะแนน)**
   - ข้อมูลติดต่อครบถ้วน
   
6. **Footer (5 คะแนน)**
   - Copyright และ Social Links
   
7. **Design และความสวยงาม (15 คะแนน)**
   - Color Scheme, Typography, Spacing

### เกณฑ์การให้คะแนน:
- แบ่งเป็น 4 ระดับ: Excellent, Good, Fair, Needs Improvement
- มี Rubric รายละเอียดสำหรับแต่ละส่วน (100 คะแนน)
- มี Checklist สำหรับนักศึกษาตรวจสอบก่อนส่ง

### ประกอบด้วย:
- ข้อกำหนดโครงสร้าง HTML
- ข้อกำหนด CSS (Media Queries, Flexible Units)
- JavaScript (Optional)
- เคล็ดลับและคำแนะนำ
- ตัวอย่าง Color Schemes
- FAQ

---

## 🎮 4. เครื่องมือเรียนรู้แบบ Interactive

**ไฟล์:** `interactive-media-queries-tool.html`

### คุณสมบัติ:
- **Slider ควบคุมขนาดหน้าจอ** (320-1920px)
- **Breakpoint Buttons แบบด่วน:**
  - iPhone (375px)
  - iPhone Plus (414px)
  - iPad (768px)
  - Desktop (1024px)
  - Large Desktop (1440px)
  - Full HD (1920px)

### แสดงผล Real-time:
- Device Type ปัจจุบัน
- Breakpoint Information
- Layout (จำนวนคอลัมน์)
- Navigation Type
- โค้ด CSS ที่ใช้

### Live Preview:
- Demo Restaurant Website
- Grid Layout เปลี่ยนตามขนาดจอ
- Navigation แสดง/ซ่อนตาม breakpoint

### เหมาะสำหรับ:
- Demo ในห้องเรียน
- ให้นักศึกษาทดลองเล่น
- เข้าใจ Media Queries แบบ Visual

---

## 📊 แผนการสอน

### สัปดาห์ที่ 7 (3 ชั่วโมง)

#### ชั่วโมงที่ 1: ทฤษฎีและแนวคิด (60 นาที)
1. **แนะนำ Responsive Web Design (15 นาที)**
   - ความหมายและความสำคัญ
   - หลักการ 3 ประการ
   - แสดง Example 1

2. **Viewport และ Meta Tag (10 นาที)**
   - อธิบายความสำคัญ
   - วิธีการใช้งาน

3. **Media Queries พื้นฐาน (20 นาที)**
   - รูปแบบและ Syntax
   - Media Types และ Conditions
   - แสดง Example 2
   - ใช้ Interactive Tool สาธิต

4. **Breakpoints (15 นาที)**
   - Breakpoints มาตรฐาน
   - การเลือก Breakpoints ที่เหมาะสม
   - Mobile-First vs Desktop-First

#### ชั่วโมงที่ 2: ปฏิบัติและตัวอย่าง (60 นาที)
1. **Responsive Navigation (20 นาที)**
   - แสดง Example 3
   - Code Walkthrough
   - JavaScript สำหรับ Hamburger Menu

2. **Responsive Layout Patterns (20 นาที)**
   - Flexible Grid
   - Card Layout
   - แสดง Example 4

3. **Best Practices (20 นาที)**
   - Flexible Units
   - Responsive Images
   - Typography
   - Testing Tips

#### ชั่วโมงที่ 3: Workshop และ Q&A (60 นาที)
1. **อธิบายแบบฝึกหัด (15 นาที)**
   - โจทย์ร้านอาหาร
   - Rubric และเกณฑ์การให้คะแนน
   - Checklist

2. **Workshop (30 นาที)**
   - นักศึกษาเริ่มทำแบบฝึกหัด
   - อาจารย์ช่วยเหลือและตอบคำถาม

3. **Q&A และสรุป (15 นาที)**
   - ตอบคำถามเพิ่มเติม
   - สรุปประเด็นสำคัญ
   - แจ้งกำหนดส่งงาน

---

## 🎯 วัตถุประสงค์การเรียนรู้

เมื่อจบบทเรียนนี้ นักศึกษาจะสามารถ:

1. ✅ **อธิบาย** แนวคิดและความสำคัญของ Responsive Web Design
2. ✅ **ใช้งาน** Viewport Meta Tag และเข้าใจการทำงาน
3. ✅ **เขียน** Media Queries เพื่อปรับแต่งการแสดงผลตามขนาดหน้าจอ
4. ✅ **กำหนด** Breakpoints ที่เหมาะสมสำหรับอุปกรณ์ต่างๆ
5. ✅ **สร้าง** เว็บไซต์ที่ตอบสนองต่อหลายขนาดหน้าจอ
6. ✅ **ปรับใช้** เทคนิค Mobile-First Approach

---

## 💡 คำแนะนำสำหรับการสอน

### 1. การนำเสนอเนื้อหา
- ใช้ Interactive Tool ในการสาธิต
- แสดงตัวอย่างโค้ดที่สมบูรณ์
- ให้นักศึกษาลองปรับขนาดหน้าจอจริง
- เปิด Chrome DevTools ให้ดู

### 2. การฝึกปฏิบัติ
- ให้นักศึกษาเปิดตัวอย่างในเครื่องตัวเอง
- ลองแก้โค้ดและดูผลลัพธ์
- ทดสอบบนอุปกรณ์จริง (มือถือ)

### 3. การให้แบบฝึกหัด
- อธิบาย Rubric อย่างละเอียด
- ให้ตัวอย่าง Good vs Bad
- แนะนำให้เริ่มจาก Mobile First
- กำหนดส่งล่วงหน้า 1-2 สัปดาห์

### 4. การตรวจและให้คะแนน
- ใช้ Rubric ที่กำหนดไว้
- ตรวจบน Chrome DevTools
- ทดสอบ Breakpoints ทั้งหมด
- ให้ Feedback เฉพาะเจาะจง

---

## 🔧 เทคนิคการ Debug

### สอนให้นักศึกษารู้จักใช้:
1. **Chrome DevTools**
   - กด F12
   - Toggle Device Toolbar (Ctrl+Shift+M)
   - เลือกอุปกรณ์ต่างๆ
   - ดู Computed Styles

2. **Responsive Design Mode (Firefox)**
   - กด Ctrl+Shift+M
   - ปรับขนาดจอได้ smooth

3. **ตรวจสอบ Media Queries**
   - ดูว่า Media Query ใช้งานหรือไม่
   - ตรวจสอบ Syntax
   - ดู Specificity

---

## 📈 การประเมินผล

### แบ่งคะแนนเป็น:
1. **แบบฝึกหัดร้านอาหาร (70%)**
   - ใช้ Rubric 100 คะแนน
   - แปลงเป็น 70 คะแนน

2. **การมีส่วนร่วมในชั้นเรียน (10%)**
   - ตอบคำถาม
   - ทำ Workshop

3. **Quiz หรือแบบทดสอบ (20%)**
   - Media Queries Syntax
   - Breakpoints
   - Best Practices

---

## 🎓 ทักษะที่นักศึกษาได้รับ

หลังจากเรียนจบสัปดาห์ที่ 7:

### Technical Skills:
- เขียน Media Queries ได้
- ใช้ Flexbox และ Grid สำหรับ Responsive Layout
- ใช้ Flexible Units (%, rem, vw, vh)
- สร้าง Responsive Navigation
- ทำให้รูปภาพ Responsive

### Soft Skills:
- Problem-solving (แก้ปัญหา Layout)
- Testing Mindset (ทดสอบหลายขนาดจอ)
- Attention to Detail (ดูรายละเอียด Spacing, Typography)
- User Empathy (คำนึงถึงผู้ใช้บนอุปกรณ์ต่างๆ)

---

## 🔗 แหล่งข้อมูลเพิ่มเติม

### สำหรับอาจารย์:
- [MDN Web Docs - Responsive Design](https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Responsive_Design)
- [A Book Apart - Responsive Web Design](https://abookapart.com/products/responsive-web-design)
- [Smashing Magazine - Responsive Design Articles](https://www.smashingmagazine.com/category/responsive-design/)

### สำหรับนักศึกษา:
- [CSS-Tricks - Complete Guide to Flexbox](https://css-tricks.com/snippets/css/a-guide-to-flexbox/)
- [CSS-Tricks - Complete Guide to Grid](https://css-tricks.com/snippets/css/complete-guide-grid/)
- [Google Web Fundamentals](https://developers.google.com/web/fundamentals/design-and-ux/responsive)

---

## 📞 ติดต่อและสนับสนุน

หากมีคำถามหรือต้องการความช่วยเหลือเพิ่มเติม:
- ติดต่ออาจารย์ผู้สอน
- ถามคำถามในกลุ่ม Line/Discord ของห้องเรียน
- ใช้ Stack Overflow สำหรับปัญหาทางเทคนิค

---

## ✨ สรุป

เอกสารชุดนี้ครบถ้วนสำหรับการสอน Responsive Web Design & Media Queries โดย:

✅ มีเนื้อหาทฤษฎีครบถ้วน  
✅ มีตัวอย่างโค้ดที่ copy-paste ได้  
✅ มีแบบฝึกหัดพร้อม Rubric ละเอียด  
✅ มี Interactive Tool สำหรับสาธิต  
✅ เหมาะสำหรับผู้เริ่มต้น  
✅ ใช้ภาษาไทยเข้าใจง่าย  

**ขอให้การสอนราบรื่นและนักศึกษาเรียนรู้ได้อย่างมีประสิทธิภาพครับ! 🎉**

---

**จัดทำโดย:** Claude (Anthropic)  
**วันที่:** 8 ธันวาคม 2025  
**เวอร์ชัน:** 1.0
